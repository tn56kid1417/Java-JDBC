package com.kishore.collection.Bookshop;
public class Login {
	private String uname;
	private String password;
	private String role;
	public void setUname(String uname)
	{
		this.uname=uname;	
	}
	public void setpassword(String password)
	{
		this.password=password;
	}
	public void setRole(String role)
	{
		this.role=role;	
	}
	public String getUname()
	{
		return this.uname;
	}
	public String getPassword()
	{
		return this.password;
	}
	public String getRole()
	{
		return this.role;
	}


}
